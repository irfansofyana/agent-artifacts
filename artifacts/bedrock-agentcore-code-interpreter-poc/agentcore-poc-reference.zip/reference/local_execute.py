"""First local Python -> remote AgentCore exercise. Explicitly billable when enabled."""
import argparse
import json
import uuid

import boto3
from botocore.config import Config


def consume(response):
    results = []
    for event in response["stream"]:
        if "result" not in event:
            raise RuntimeError(f"Service stream failure: {event}")
        result = event["result"]
        exit_code = result.get("structuredContent", {}).get("exitCode")
        if result.get("isError") or exit_code not in (None, 0):
            raise RuntimeError(f"Sandbox execution failed: {result}")
        results.append(result)
    if not results:
        raise RuntimeError("Service returned no results")
    return results


def run(client, interpreter_id):
    started = client.start_code_interpreter_session(
        codeInterpreterIdentifier=interpreter_id, name="local-poc",
        sessionTimeoutSeconds=600, clientToken=str(uuid.uuid4()),
    )
    sid = started["sessionId"]
    print(json.dumps({"session_id": sid, "interpreter_id": interpreter_id}))
    try:
        results = consume(client.invoke_code_interpreter(
            codeInterpreterIdentifier=interpreter_id, sessionId=sid,
            name="executeCode", arguments={
                "language": "python", "code":
                "import json; values=[10,20,30]; assert sum(values)==60; "
                "print(json.dumps({'total':sum(values)}))",
            },
        ))
        print(json.dumps(results, indent=2, default=str))
        return results
    finally:
        client.stop_code_interpreter_session(codeInterpreterIdentifier=interpreter_id, sessionId=sid)
        try:
            status = client.get_code_interpreter_session(
                codeInterpreterIdentifier=interpreter_id, sessionId=sid)["status"]
        except client.exceptions.ResourceNotFoundException:
            status = "TERMINATED"
        if status != "TERMINATED":
            raise RuntimeError(f"Cleanup not yet verified: session={sid} status={status}")
        print(json.dumps({"session_id": sid, "cleanup": status}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--interpreter-id", required=True)
    parser.add_argument("--allow-live", action="store_true")
    args = parser.parse_args()
    if not args.allow_live or args.interpreter_id.startswith("aws."):
        parser.error("Provide --allow-live and the custom interpreter ID created earlier")
    client = boto3.client("bedrock-agentcore", region_name="us-west-2", config=Config(
        connect_timeout=10, read_timeout=120, retries={"mode": "standard", "total_max_attempts": 1},
    ))
    run(client, args.interpreter_id)


if __name__ == "__main__":
    main()
