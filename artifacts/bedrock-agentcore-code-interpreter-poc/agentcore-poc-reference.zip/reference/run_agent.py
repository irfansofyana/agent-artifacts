"""Explicit live entrypoint for the two framework examples."""
import argparse
import asyncio
import os
import uuid

from langchain_aws import ChatBedrockConverse
from agentcore_examples import run_deep, run_plain


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["deep", "langchain"])
    parser.add_argument("--allow-live", action="store_true")
    args = parser.parse_args()
    if not args.allow_live:
        parser.error("--allow-live is required; this calls AWS and a billable model")
    interpreter_id = os.environ["AGENTCORE_CODE_INTERPRETER_ID"]
    if not interpreter_id or interpreter_id.startswith("aws."):
        parser.error("Use the Terraform-created custom interpreter ID")
    model_id = os.environ["BEDROCK_MODEL_ID"]
    model = ChatBedrockConverse(
        model_id=model_id, region_name="us-west-2", temperature=0,
        max_tokens=1024,
    )
    if args.mode == "deep":
        result = run_deep(model, interpreter_id)
    else:
        result = asyncio.run(run_plain(model, interpreter_id, str(uuid.uuid4())))
    for message in result["messages"]:
        print(message.type, message.content)


if __name__ == "__main__":
    main()
