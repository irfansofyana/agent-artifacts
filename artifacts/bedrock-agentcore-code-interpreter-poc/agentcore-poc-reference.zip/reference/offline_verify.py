"""Offline verification only: SDK transport and model are mocks, not AWS observations."""
import asyncio
import importlib.util
import inspect
import socket
import sys
from unittest.mock import MagicMock, patch

import os
EXPECT_FIXED = os.environ.get("EXPECT_FIXED", "1") == "1"
import agentcore_examples as examples
from bedrock_agentcore.tools.code_interpreter_client import CodeInterpreter
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_agentcore_codeinterpreter import AgentCoreSandbox

CUSTOM_ID = "private_interpreter-abcdefghij"

class LocalModel(BaseChatModel):
    tool_name: str

    @property
    def _llm_type(self):
        return "offline-contract-test"

    def bind_tools(self, tools, **kwargs):
        assert self.tool_name in [t.name for t in tools if hasattr(t, "name")]
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        if any(isinstance(m, ToolMessage) for m in messages):
            msg = AIMessage(content="Offline model saw a tool response.")
        else:
            msg = AIMessage(content="", tool_calls=[{
                "name": self.tool_name, "args": {"command": "cat input.txt"}, "id": "offline-call"
            }])
        return ChatResult(generations=[ChatGeneration(message=msg)])


def make_sdk():
    session = MagicMock()
    cp = MagicMock()
    dp = MagicMock()
    session.client.side_effect = lambda name, **kwargs: cp if name.endswith("-control") else dp
    sdk = CodeInterpreter(region="us-west-2", session=session)
    dp.start_code_interpreter_session.return_value = {
        "codeInterpreterIdentifier": CUSTOM_ID, "sessionId": "offline-session"
    }
    files = {}
    def invoke(**kwargs):
        method, args = kwargs["name"], kwargs["arguments"]
        if method == "writeFiles":
            for f in args["content"]:
                files[f["path"]] = f.get("text", f.get("blob"))
            content = [{"type": "text", "text": "mock write accepted"}]
        elif method == "readFiles":
            content = []
            for path in args["paths"]:
                if path in files:
                    value = files[path]
                    content.append({"type": "resource", "resource": {
                        "uri": "file://" + path, "text" if isinstance(value, str) else "blob": value
                    }})
        else:
            output = "/mock/cwd" if args.get("command") == "pwd" else "hello\n"
            content = [{"type": "text", "text": output}]
        return {"stream": iter([{"result": {"content": content, "structuredContent": {"exitCode": 0}, "isError": False}}])}
    dp.invoke_code_interpreter.side_effect = invoke
    return sdk, dp


def verify_examples(backend_cls):
    sdk, dp = make_sdk()
    with patch.object(examples, "CodeInterpreter", return_value=sdk), patch.object(examples, "AgentCoreSandbox", backend_cls):
        result = examples.run_deep(LocalModel(tool_name="execute"), CUSTOM_ID)
    assert any(isinstance(m, ToolMessage) and "hello" in str(m.content) for m in result["messages"])
    assert dp.start_code_interpreter_session.call_args.kwargs["codeInterpreterIdentifier"] == CUSTOM_ID
    assert dp.start_code_interpreter_session.call_args.kwargs["sessionTimeoutSeconds"] == 1800
    dp.stop_code_interpreter_session.assert_called_once_with(codeInterpreterIdentifier=CUSTOM_ID, sessionId="offline-session")
    assert sdk.session_id is None
    print(backend_cls.__module__, "Deep Agents tool round-trip/custom-ID/start-stop/read-back PASS")


def detect_release_caveats(backend_cls):
    interpreter = MagicMock()
    interpreter.session_id = "offline-session"
    interpreter.invoke.side_effect = lambda **kwargs: {"stream": iter([{"result": {
        "content": [{"type": "text", "text": "command failed"}],
        "structuredContent": {"exitCode": 7}, "isError": True
    }}])}
    backend = backend_cls(interpreter=interpreter, cwd="/mock/cwd")
    result = backend.execute("false", timeout=1)
    sent = interpreter.invoke.call_args.kwargs["params"]["command"]
    uploaded = backend.upload_files([("bad.txt", b"x")])[0]
    print(backend_cls.__module__, {"structured_exit_7_returned_as": result.exit_code,
          "timeout_command_sent": sent, "isError_upload_reported_error": uploaded.error,
          "has_create": hasattr(backend_cls, "create")})
    if not EXPECT_FIXED:
        assert result.exit_code == 0 and sent == "false" and uploaded.error is None
    else:
        assert result.exit_code == 7 and sent.startswith("timeout -k 5") and uploaded.error is not None


def verify_binary(backend_cls):
    sdk, dp = make_sdk()
    sdk.start(identifier=CUSTOM_ID)
    backend = backend_cls(interpreter=sdk, cwd="/mock/cwd")
    blob = b"\xff\x00\x80"
    assert backend.upload_files([("binary.dat", blob)])[0].error is None
    assert backend.download_files(["binary.dat"])[0].content == blob
    assert backend.download_files(["missing.dat"])[0].error == "file_not_found"
    sdk.stop()
    print(backend_cls.__module__, "raw binary bytes/partial missing-file PASS")


async def verify_plain():
    sdk, dp = make_sdk()
    with patch("langchain_aws.tools.code_interpreter_toolkit.CodeInterpreter", return_value=sdk):
        result = await examples.run_plain(LocalModel(tool_name="execute_command"), CUSTOM_ID, "job-unique")
    assert any(isinstance(m, ToolMessage) and "hello" in str(m.content) for m in result["messages"])
    assert dp.start_code_interpreter_session.call_args.kwargs["codeInterpreterIdentifier"] == CUSTOM_ID
    dp.stop_code_interpreter_session.assert_called_once()
    print("Native LangChain toolkit tool round-trip/custom-ID/lazy-session/cleanup PASS")


def test_raw_stream():
    from direct_smoke import collect, resource_bytes
    good = {"stream": iter([{"result": {"content": [{"type": "resource", "resource": {"blob": b"\xff\x00"}}], "structuredContent": {"exitCode": 0}}}])}
    assert resource_bytes(collect(good)) == b"\xff\x00"
    for event in [
        {"result": {"isError": True}},
        {"result": {"structuredContent": {"exitCode": 7}}},
        {"throttlingException": {}},
    ]:
        try:
            collect({"stream": iter([event])})
        except RuntimeError:
            pass
        else:
            raise AssertionError("Raw stream parser accepted an error")
    print("Raw stream success/binary/error-event/exit-code classification PASS")


def main():
    with patch.object(socket.socket, "connect", side_effect=AssertionError("Network forbidden in offline tests")), patch.object(socket, "create_connection", side_effect=AssertionError("Network forbidden in offline tests")):
        verify_examples(AgentCoreSandbox)
        verify_binary(AgentCoreSandbox)
        detect_release_caveats(AgentCoreSandbox)
        asyncio.run(verify_plain())
        test_raw_stream()
    print("ALL OFFLINE ASSERTIONS PASS; AWS transport and model mocked; no cloud execution")

if __name__ == "__main__":
    main()
