"""Offline prerequisite checks, not a complete AWS authorization evaluator."""
import json
from pathlib import Path
import socket
from unittest.mock import MagicMock, patch

import botocore.session
from botocore.validate import validate_parameters

from prepare_poc import generate
from local_execute import run, consume

ACCOUNT = "111122223333"
TOOL_ID = "agentcore_poc-AbCdEf1234"
ARN = f"arn:aws:bedrock-agentcore:us-west-2:{ACCOUNT}:code-interpreter-custom/{TOOL_ID}"


def main():
    with patch.object(socket.socket, "connect", side_effect=AssertionError("No network in offline tests")), patch.object(socket, "create_connection", side_effect=AssertionError("No network in offline tests")):
        files = generate(ACCOUNT, "ApprovedAgentCorePocExecution", ARN)
        assert len(files) == 6
        assert files["create-interpreter.json"]["networkConfiguration"] == {"networkMode": "SANDBOX"}
        assert files["iam-caller.json"]["Statement"][0]["Resource"] == ARN
        assert all(s["Effect"] == "Allow" for s in files["scp-allowlist-addition.json"]["Statement"])
        pass_role = files["iam-deployer.json"]["Statement"][-1]
        assert pass_role["Resource"] == f"arn:aws:iam::{ACCOUNT}:role/ApprovedAgentCorePocExecution"
        assert pass_role["Condition"]["StringEquals"]["iam:PassedToService"] == "bedrock-agentcore.amazonaws.com"
        for account, role, arn in [
            ("123", "Role", None), (ACCOUNT + " ", "Role", None),
            (ACCOUNT, "path/Role", None), (ACCOUNT, "Role", ARN.replace("us-west-2", "us-east-1")),
        ]:
            try:
                generate(account, role, arn)
            except ValueError:
                pass
            else:
                raise AssertionError("Malformed or mismatched identifier accepted")
        catalog = json.loads((Path(__file__).parent/"aws-agentcore-authorization.json").read_text())
        actions = {x["Name"] for x in catalog["Actions"]}
        for value in files.values():
            for st in value.get("Statement", []):
                names = st["Action"] if isinstance(st["Action"], list) else [st["Action"]]
                for name in names:
                    if name.startswith("bedrock-agentcore:") and "*" not in name:
                        assert name.split(":", 1)[1] in actions, name
        session = botocore.session.get_session()
        cp = session.get_service_model("bedrock-agentcore-control")
        dp = session.get_service_model("bedrock-agentcore")
        validate_parameters(files["create-interpreter.json"], cp.operation_model("CreateCodeInterpreter").input_shape)
        print("Generator/scoped policy/identifier/action catalog/CreateCodeInterpreter shape PASS")

        client = MagicMock()
        client.exceptions.ResourceNotFoundException = type("Missing", (Exception,), {})
        client.start_code_interpreter_session.return_value = {"sessionId": "OfflineSession1"}
        client.get_code_interpreter_session.return_value = {"status": "TERMINATED"}
        def invoke(**kwargs):
            validate_parameters(kwargs, dp.operation_model("InvokeCodeInterpreter").input_shape)
            return {"stream": iter([{"result": {"content": [{"type": "text", "text": "mocked total"}], "structuredContent": {"exitCode": 0}, "isError": False}}])}
        client.invoke_code_interpreter.side_effect = invoke
        run(client, TOOL_ID)
        for call in client.start_code_interpreter_session.call_args_list:
            validate_parameters(call.kwargs, dp.operation_model("StartCodeInterpreterSession").input_shape)
        client.stop_code_interpreter_session.assert_called_once_with(codeInterpreterIdentifier=TOOL_ID, sessionId="OfflineSession1")
        print("Local Python sequence/schema/custom-ID/termination-read-back PASS (mock transport)")
        client.reset_mock()
        client.invoke_code_interpreter.side_effect = lambda **kwargs: {"stream": iter([{"result": {"isError": True}}])}
        try:
            run(client, TOOL_ID)
        except RuntimeError:
            pass
        else:
            raise AssertionError("Execution error accepted")
        client.stop_code_interpreter_session.assert_called_once()
        for event in [{"throttlingException": {}}, {"result": {"structuredContent": {"exitCode": 7}}}]:
            try:
                consume({"stream": iter([event])})
            except RuntimeError:
                pass
            else:
                raise AssertionError("Stream failure accepted")
        print("Failure propagation and finally-cleanup PASS")
    print("ALL PREREQUISITE CONTRACT CHECKS PASS; no live IAM/SCP/API evaluation performed")


if __name__ == "__main__":
    main()
