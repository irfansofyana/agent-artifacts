"""AWS examples: importing is safe; calling requires AWS and a tool-capable model."""
from bedrock_agentcore.tools.code_interpreter_client import CodeInterpreter
from langchain_agentcore_codeinterpreter import AgentCoreSandbox
from deepagents import create_deep_agent
from langchain.agents import create_agent
from langchain_aws.tools import create_code_interpreter_toolkit

REGION = "us-west-2"


def run_deep(model, interpreter_id: str, boto3_session=None):
    # interpreter_id must be the pre-provisioned READY custom interpreter ID.
    interpreter = CodeInterpreter(region=REGION, session=boto3_session)
    interpreter.start(identifier=interpreter_id, session_timeout_seconds=1800)
    try:
        backend = AgentCoreSandbox(interpreter=interpreter)
        # Relative paths avoid assuming a service-specific sandbox cwd.
        uploaded = backend.upload_files([("input.txt", b"hello\n")])
        if uploaded[0].error:
            raise RuntimeError(uploaded[0].error)
        # Read-back matters: release 0.0.5 may falsely report an upload success.
        downloaded = backend.download_files(["input.txt"])[0]
        if downloaded.error or downloaded.content != b"hello\n":
            raise RuntimeError("Upload read-back failed")
        agent = create_deep_agent(
            model=model, backend=backend,
            system_prompt="Run cat input.txt with execute and report its output."
        )
        return agent.invoke({"messages": [{"role": "user", "content": "Read input.txt using the shell."}]})
    finally:
        interpreter.stop()


async def run_plain(model, interpreter_id: str, thread_id: str):
    # Native supported LangChain toolkit; no custom tool adapter.
    toolkit, tools = await create_code_interpreter_toolkit(
        region=REGION, code_interpreter_identifier=interpreter_id
    )
    config = {"configurable": {"thread_id": thread_id}}
    try:
        by_name = {tool.name: tool for tool in tools}
        # Creates the session lazily; same config keeps upload and execution together.
        await by_name["upload_file"].ainvoke(
            {"path": "input.txt", "content": "hello\n"}, config=config
        )
        agent = create_agent(model=model, tools=tools,
                             system_prompt="Run cat input.txt with execute_command and report its output.")
        return await agent.ainvoke(
            {"messages": [{"role": "user", "content": "Read input.txt using the shell."}]},
            config=config,
        )
    finally:
        # One toolkit per request here; stops every session it created.
        await toolkit.cleanup()


# Explicit opt-in production invocation only (not run during research):
# import asyncio, os
# from langchain_aws import ChatBedrockConverse
# model = ChatBedrockConverse(model_id=os.environ["BEDROCK_MODEL_ID"], region_name=REGION)
# result = run_deep(model, os.environ["AGENTCORE_CODE_INTERPRETER_ID"])
# result = asyncio.run(run_plain(model, os.environ["AGENTCORE_CODE_INTERPRETER_ID"], "unique-job-id"))
