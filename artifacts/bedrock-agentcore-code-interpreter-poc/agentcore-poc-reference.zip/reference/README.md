# AgentCore Code Interpreter POC reference

Use the accompanying `agentcore-code-interpreter-runbook.md` or PDF for the full procedure and security gates.

Baseline: company AWS account, us-west-2, a custom SANDBOX interpreter. No customer VPC, NAT gateway, ECR image or AgentCore Runtime is required by the baseline.

## Practical order (revision 2)

Approve SCPs and account/region first, prepare the platform-owned execution role and deployer permissions, create the custom tool through console/CLI, attach caller permissions to its exact ARN, and run `local_execute.py` before installing agent frameworks. Adopt the working tool into Terraform later; do not create a duplicate by accident.

`prepare_poc.py` generates local request/SCP/IAM JSON only and never contacts AWS or changes policies. `policy-examples/` contains illustrative AWS documentation account IDs; replace them only with reviewed inputs. An Allow cannot override an explicit SCP Deny.

First-script environment: `python -m pip install boto3==1.43.113`. Then run `python local_execute.py --interpreter-id "$AGENTCORE_CODE_INTERPRETER_ID" --allow-live` with the approved caller profile. Local means client execution on the workstation; the code runs remotely in AWS and incurs charges.

`prerequisites_verify.py` checks the generator, identifier preservation, public action catalog, AWS request shapes and the local client's mocked error/cleanup sequence. It is not a full IAM/SCP evaluator. The included `aws-agentcore-authorization.json` is a public AWS catalog snapshot.

`verification.txt` contains actual local output with workspace/venv paths normalized for public distribution. No company policy, credentials or real cloud success output is included.

## Local checks

From `reference/`, create and activate an isolated environment with your company's approved Python and package mirror. The tested environment used Python 3.14.7.

```bash
python -m pip install -r requirements-candidate.txt
python -m pip check
python offline_verify.py
terraform -chdir=terraform/interpreter init -backend=false
terraform -chdir=terraform/interpreter validate
terraform -chdir=terraform/interpreter test
```

Terraform tests use a mock provider and require Terraform >=1.7. The validated CLI was Terraform 1.16.5 with AWS provider 6.68.0. `init` needs a provider download/mirror but these tests do not need AWS credentials.

The candidate uses an immutable upstream source commit because the published sandbox 0.0.5 has reproduced timeout/error-reporting defects. Obtain company approval before using a VCS dependency; prefer a reviewed wheel in the company's private repository. `EXPECT_FIXED=0 python offline_verify.py` in the published-release environment checks that the documented defects can be reproduced. That is not production acceptance.

## Live checks: approval required

First review the runbook's IAM, account, model and network prerequisites. Configure normal company AWS credentials; never hard-code keys.

After console/CLI creation (or later Terraform adoption), supply the exact custom interpreter ID:

```bash
python direct_smoke.py --interpreter-id "$AGENTCORE_CODE_INTERPRETER_ID" --allow-live
python run_agent.py deep --allow-live
python run_agent.py langchain --allow-live
```

The agent commands additionally require `BEDROCK_MODEL_ID` set to a company-approved tool-capable Bedrock model. Calls incur AWS/model charges. The direct smoke needs no model. `artifacts/direct-smoke.json` records real test evidence only when the live CLI is run; no pre-generated cloud success evidence is included.

Platform owners provide the execution role and attach the emitted caller policy. Optional endpoints and VPC mode are extensions, not baseline requirements. Protect Terraform state and use the company backend/approval process. Plan/apply/destroy commands are intentionally not run as part of producing this bundle.

`verification.txt` contains actual local test output. Python AWS transport/model calls are mocked in those tests; Terraform uses mock-provider plans. Company AWS permissions, service execution and connectivity remain unverified until you run the authorized live steps.
