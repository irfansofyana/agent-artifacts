"""Generate local POC request/policy files. Does not call AWS or change SCPs."""
import argparse
import json
import re
from pathlib import Path

REGION = "us-west-2"
CONTROL_ACTIONS = [
    "CreateCodeInterpreter", "GetCodeInterpreter", "ListCodeInterpreters",
    "DeleteCodeInterpreter", "TagResource", "UntagResource", "ListTagsForResource",
]
CALLER_ACTIONS = [
    "StartCodeInterpreterSession", "InvokeCodeInterpreter", "StopCodeInterpreterSession",
    "GetCodeInterpreterSession", "ListCodeInterpreterSessions",
]


def policy(statements):
    return {"Version": "2012-10-17", "Statement": statements}


def generate(account_id, role_name, interpreter_arn=None):
    if not re.fullmatch(r"[0-9]{12}", account_id):
        raise ValueError("Account ID must be exactly 12 digits")
    if not re.fullmatch(r"[A-Za-z0-9+=,.@_-]{1,64}", role_name):
        raise ValueError("Supply an IAM role name, without a role path, for this example")
    role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"
    prefix = f"arn:aws:bedrock-agentcore:{REGION}:{account_id}:code-interpreter-custom/"
    region_condition = {"StringEquals": {"aws:RequestedRegion": REGION}}
    files = {
        "execution-role-trust.json": policy([{
            "Effect": "Allow", "Principal": {"Service": "bedrock-agentcore.amazonaws.com"},
            "Action": "sts:AssumeRole", "Condition": {
                "StringEquals": {"aws:SourceAccount": account_id},
                "ArnLike": {"aws:SourceArn": f"arn:aws:bedrock-agentcore:{REGION}:{account_id}:*"},
            },
        }]),
        "create-interpreter.json": {
            "name": "agentcore_poc", "description": "Deep Agents Code Interpreter POC",
            "executionRoleArn": role_arn,
            "networkConfiguration": {"networkMode": "SANDBOX"},
            "tags": {"Purpose": "agentcore-code-interpreter-poc"},
        },
        "scp-allowlist-addition.json": policy([{
            "Sid": "PermitCodeInterpreterPocCeiling",
            "Effect": "Allow", "Action": ["bedrock-agentcore:" + x for x in CONTROL_ACTIONS + CALLER_ACTIONS],
            "Resource": "*", "Condition": region_condition,
        }]),
        "scp-broader-agentcore-optional.json": policy([{
            "Sid": "OptionalWholeAgentCoreNamespaceCeiling",
            "Effect": "Allow", "Action": "bedrock-agentcore:*",
            "Resource": "*", "Condition": region_condition,
        }]),
        "iam-deployer.json": policy([
            {"Effect": "Allow", "Action": ["bedrock-agentcore:CreateCodeInterpreter", "bedrock-agentcore:ListCodeInterpreters"],
             "Resource": "*", "Condition": region_condition},
            {"Effect": "Allow", "Action": ["bedrock-agentcore:" + x for x in CONTROL_ACTIONS if x not in ("CreateCodeInterpreter", "ListCodeInterpreters")],
             "Resource": prefix + "*", "Condition": region_condition},
            {"Effect": "Allow", "Action": "iam:PassRole", "Resource": role_arn,
             "Condition": {"StringEquals": {"iam:PassedToService": "bedrock-agentcore.amazonaws.com"}}},
        ]),
    }
    if interpreter_arn:
        if not re.fullmatch(re.escape(prefix) + r"[A-Za-z][A-Za-z0-9_]{0,47}-[A-Za-z0-9]{10}", interpreter_arn):
            raise ValueError("Interpreter ARN must be the exact returned custom ARN for this account and region")
        files["iam-caller.json"] = policy([{
            "Effect": "Allow", "Action": ["bedrock-agentcore:" + x for x in CALLER_ACTIONS],
            "Resource": interpreter_arn,
        }])
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--account-id", required=True)
    parser.add_argument("--execution-role-name", required=True)
    parser.add_argument("--interpreter-arn")
    parser.add_argument("--output-dir", default="generated")
    args = parser.parse_args()
    files = generate(args.account_id, args.execution_role_name, args.interpreter_arn)
    dest = Path(args.output_dir)
    dest.mkdir(parents=True, exist_ok=True)
    for name, value in files.items():
        path = dest / name
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite {path}; use a fresh output directory")
    for name, value in files.items():
        (dest/name).write_text(json.dumps(value, indent=2) + "\n")
    print(f"Generated {len(files)} local files in {dest}. No AWS calls; no policies applied.")


if __name__ == "__main__":
    main()
