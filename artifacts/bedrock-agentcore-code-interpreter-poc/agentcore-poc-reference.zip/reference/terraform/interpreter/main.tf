terraform {
  required_version = ">= 1.5.0, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 6.68.0"
    }
  }
}

provider "aws" {
  region              = "us-west-2"
  allowed_account_ids = [var.account_id]
  default_tags {
    tags = {
      Purpose = "agentcore-code-interpreter-poc"
      Owner   = var.owner
    }
  }
}

variable "account_id" {
  type = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "Supply the approved company account ID."
  }
}
variable "owner" { type = string }
variable "execution_role_arn" { type = string }
variable "network_mode" {
  type    = string
  default = "SANDBOX"
  validation {
    condition     = contains(["SANDBOX", "VPC"], var.network_mode)
    error_message = "This POC permits SANDBOX or approved VPC mode; PUBLIC is intentionally excluded."
  }
}
variable "tool_subnet_ids" {
  type    = set(string)
  default = []
}
variable "tool_security_group_ids" {
  type    = set(string)
  default = []
}

resource "aws_bedrockagentcore_code_interpreter" "poc" {
  name               = "agentcore_poc"
  description        = "Deep Agents Code Interpreter POC"
  execution_role_arn = var.execution_role_arn
  network_configuration {
    network_mode = var.network_mode
    dynamic "vpc_config" {
      for_each = var.network_mode == "VPC" ? [1] : []
      content {
        subnets         = var.tool_subnet_ids
        security_groups = var.tool_security_group_ids
      }
    }
  }
  lifecycle {
    precondition {
      condition = var.network_mode != "VPC" || (
        length(var.tool_subnet_ids) >= 2 && length(var.tool_subnet_ids) <= 16 &&
        length(var.tool_security_group_ids) >= 1 && length(var.tool_security_group_ids) <= 16
      )
      error_message = "VPC requires 2-16 approved subnets in distinct supported AZs and 1-16 security groups."
    }
  }
  timeouts {
    create = "30m"
    delete = "30m"
  }
}

output "code_interpreter_id" {
  value = aws_bedrockagentcore_code_interpreter.poc.code_interpreter_id
}
output "code_interpreter_arn" {
  value = aws_bedrockagentcore_code_interpreter.poc.code_interpreter_arn
}
output "caller_policy_json" {
  value = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "bedrock-agentcore:StartCodeInterpreterSession",
        "bedrock-agentcore:InvokeCodeInterpreter",
        "bedrock-agentcore:StopCodeInterpreterSession",
        "bedrock-agentcore:GetCodeInterpreterSession",
        "bedrock-agentcore:ListCodeInterpreterSessions"
      ]
      Resource = aws_bedrockagentcore_code_interpreter.poc.code_interpreter_arn
    }]
  })
}
