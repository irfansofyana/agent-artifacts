mock_provider "aws" {
  mock_resource "aws_bedrockagentcore_code_interpreter" {
    defaults = {
      code_interpreter_id  = "agentcore_poc-offline123"
      code_interpreter_arn = "arn:aws:bedrock-agentcore:us-west-2:111122223333:code-interpreter-custom/agentcore_poc-offline123"
    }
  }
}
variables {
  account_id         = "111122223333"
  owner              = "offline-test"
  execution_role_arn = "arn:aws:iam::111122223333:role/OfflineExecution"
}
run "sandbox_without_vpc" {
  command = plan
  assert {
    condition     = aws_bedrockagentcore_code_interpreter.poc.network_configuration[0].network_mode == "SANDBOX"
    error_message = "Baseline must be SANDBOX."
  }
  assert {
    condition     = length(aws_bedrockagentcore_code_interpreter.poc.network_configuration[0].vpc_config) == 0
    error_message = "Baseline must not attach to a VPC."
  }
}
run "approved_vpc_extension" {
  command = plan
  variables {
    network_mode            = "VPC"
    tool_subnet_ids         = ["subnet-0123456789abcdef0", "subnet-0123456789abcdef1"]
    tool_security_group_ids = ["sg-0123456789abcdef0"]
  }
  assert {
    condition     = length(aws_bedrockagentcore_code_interpreter.poc.network_configuration[0].vpc_config[0].subnets) == 2
    error_message = "VPC extension must use the supplied subnets."
  }
}
run "reject_vpc_without_network_inputs" {
  command = plan
  variables { network_mode = "VPC" }
  expect_failures = [aws_bedrockagentcore_code_interpreter.poc]
}
run "reject_public" {
  command = plan
  variables { network_mode = "PUBLIC" }
  expect_failures = [var.network_mode]
}
