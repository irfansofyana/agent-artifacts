# Optional root: platform/network owners only. Reuse existing endpoints instead
# if they already provide these services with private DNS in the target VPC.
terraform {
  required_version = ">= 1.5.0, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 6.68.0"
    }
  }
}
provider "aws" {
  region              = "us-west-2"
  allowed_account_ids = [var.account_id]
}
variable "account_id" { type = string }
variable "vpc_id" { type = string }
variable "endpoint_subnet_ids" { type = set(string) }
variable "endpoint_security_group_ids" { type = set(string) }
# Explicit policies, reviewed by company security; no default full-access policy.
variable "data_endpoint_policy_json" { type = string }
variable "control_endpoint_policy_json" { type = string }

resource "aws_vpc_endpoint" "data" {
  vpc_id              = var.vpc_id
  service_name        = "com.amazonaws.us-west-2.bedrock-agentcore"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true
  subnet_ids          = var.endpoint_subnet_ids
  security_group_ids  = var.endpoint_security_group_ids
  policy              = var.data_endpoint_policy_json
  tags                = { Purpose = "agentcore-code-interpreter-poc" }
}
resource "aws_vpc_endpoint" "control" {
  vpc_id              = var.vpc_id
  service_name        = "com.amazonaws.us-west-2.bedrock-agentcore-control"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true
  subnet_ids          = var.endpoint_subnet_ids
  security_group_ids  = var.endpoint_security_group_ids
  policy              = var.control_endpoint_policy_json
  tags                = { Purpose = "agentcore-code-interpreter-poc" }
}
output "data_endpoint_id" { value = aws_vpc_endpoint.data.id }
output "control_endpoint_id" { value = aws_vpc_endpoint.control.id }
