"""Live, billable smoke test. Run only after company approval. No LLM needed."""
import argparse
import base64
import json
import uuid
from pathlib import Path

import boto3
from botocore.config import Config


def collect(response, allow_failure=False):
    """Consume the lazy stream and fail on service, tool, or command errors."""
    results = []
    for event in response["stream"]:
        if "result" not in event:
            raise RuntimeError(f"Unexpected service event: {event}")
        result = event["result"]
        results.append(result)
        code = result.get("structuredContent", {}).get("exitCode")
        if not allow_failure and (result.get("isError") or code not in (None, 0)):
            raise RuntimeError(f"Execution failed: {result}")
    if not results:
        raise RuntimeError("Empty result stream")
    return results


def resource_bytes(results):
    for result in results:
        for item in result.get("content", []):
            resource = item.get("resource", {})
            if "blob" in resource:
                value = resource["blob"]
                return value if isinstance(value, bytes) else base64.b64decode(value, validate=True)
            if "text" in resource:
                return resource["text"].encode()
    raise RuntimeError("No file resource in readFiles result")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--interpreter-id", required=True)
    parser.add_argument("--allow-live", action="store_true")
    args = parser.parse_args()
    if not args.allow_live:
        parser.error("Explicit --allow-live required; this creates billable sessions")
    if args.interpreter_id.startswith("aws."):
        parser.error("Use your Terraform-created custom interpreter ID")
    client = boto3.client("bedrock-agentcore", region_name="us-west-2", config=Config(
        read_timeout=120, connect_timeout=10, retries={"mode": "standard", "max_attempts": 3}))
    sessions = []
    evidence = {"region": "us-west-2", "interpreter_id": args.interpreter_id, "checks": {}}
    try:
        for index in range(2):
            response = client.start_code_interpreter_session(
                codeInterpreterIdentifier=args.interpreter_id,
                name=f"poc-smoke-{index}", sessionTimeoutSeconds=600,
                clientToken=str(uuid.uuid4()))
            sessions.append(response["sessionId"])
        assert len(set(sessions)) == 2
        evidence["session_ids"] = sessions.copy()
        print(json.dumps({"session_ids": sessions}))

        def invoke(sid, name, arguments, allow_failure=False):
            return collect(client.invoke_code_interpreter(
                codeInterpreterIdentifier=args.interpreter_id, sessionId=sid,
                name=name, arguments=arguments), allow_failure)

        binary = b"\xff\x00\x80agentcore-poc"
        invoke(sessions[0], "writeFiles", {"content": [{"path": "poc.bin", "blob": binary}]})
        received = resource_bytes(invoke(sessions[0], "readFiles", {"paths": ["poc.bin"]}))
        assert received == binary, "Binary upload/download mismatch"
        evidence["checks"]["binary_round_trip"] = True
        invoke(sessions[0], "executeCode", {"language": "python", "code":
            "import pathlib; pathlib.Path('poc_marker.txt').write_text('session-one'); "
            "print(sum([10, 20, 30])); assert sum([10, 20, 30]) == 60"})
        invoke(sessions[1], "executeCode", {"language": "python", "code":
            "import pathlib; assert not pathlib.Path('poc_marker.txt').exists(); print('isolated')"})
        evidence["checks"]["computation_and_session_isolation"] = True
        failure = invoke(sessions[0], "executeCommand", {"command": "sh -c 'exit 7'"}, True)
        assert any(r.get("structuredContent", {}).get("exitCode") == 7 for r in failure), failure
        evidence["checks"]["negative_exit_code_7"] = True
        print("Direct service smoke checks passed; stopping sessions")
    finally:
        cleanup_errors = []
        for sid in sessions:
            try:
                client.stop_code_interpreter_session(
                    codeInterpreterIdentifier=args.interpreter_id, sessionId=sid)
                state = client.get_code_interpreter_session(
                    codeInterpreterIdentifier=args.interpreter_id, sessionId=sid)
                status = state.get("status")
                if status != "TERMINATED":
                    raise RuntimeError(f"Stop not verified: session={sid} status={status}")
            except client.exceptions.ResourceNotFoundException:
                pass  # Exact session lookup confirms it is no longer addressable.
            except Exception as exc:
                cleanup_errors.append(f"{sid}: {exc}")
        evidence["cleanup_errors"] = cleanup_errors
        Path("artifacts").mkdir(exist_ok=True)
        Path("artifacts/direct-smoke.json").write_text(json.dumps(evidence, indent=2))
        if cleanup_errors:
            raise RuntimeError(f"Cleanup needs operator action: {cleanup_errors}")
    print("PASS: direct API checks and session termination read-back")


if __name__ == "__main__":
    main()
